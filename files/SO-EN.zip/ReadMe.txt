Thank you for downloading my AutoSplit images for TCSO!
_______________________________________________________

These images & settings are to be used with AutoSplit 2.0 or newer.

https://www.keidran.tk/autosplitters

INSTRUCTIONS:

Video: http://bit.do/AutoSplit_Setup (YT Link)

1. Please ensure you have the recommend AutoSplit downloaded from my site, as this has been tested and confirmed to work in most situations.
2. Within a folder, place this image folder, the AutoSplit.exe file, and the tcso.toml file.
3. Move the LiveSplit.AutoSplitIntegration.dll into your LiveSplit components folder (often C:\Program Files x86\LiveSplit\Components).
4. Start OBS (or whatever software you use to record/stream), and start LiveSplit.
5. Open the Layout Editor in LiveSplit (Right click > Edit Layout) and click the plus icon, hover over Control, and click "AutoSplit Integration"
6. Double click AutoSplit Integration in the list and click Browse on the AutoSplit Path. Navigate to the folder you have for the .exe
7. Once selected, click BRwose for the Settings Path, and select the tcso.toml file. Click OK once done.
8. With AutoSplit open, first click Browse to slect the Split Image Folder, and choose the folder you downloaded.
9. Next, check the below by going to File > Settings. (This should already be configured but check this is the case.)

Capture Settings:
60 FPS limit
Live Capture Region
Capture Method - Windows Graphics Capture (this will add a yellow border on Windows 10)
Capture Device - Select your webcam or capture card. This isn't actually used.

Image Settings:
Comparison Method - L2 Norm
Default Similarity - 0.88 (this may need adjusting)
Defaut Delay - 1216
Default Pause - 30

10. With the Settings confirmed, close them and if any changes have been made, click File > Save Profile
11. Click "Select Window" and click your OBS window. Ensure this appears in the Capture Region.
12. Click "Select Region" and select your capture as close as you can.
13. Adjust the X, Y / Width, Height values until only your capture is within the border with no bleed. (Using the Windows Magnifier can help with this task.)
15. With this all in place, you are ready to go!


FAQ:
Q - My live similarity is never reaching the threshold
A - This can either be because the threshold is too high, or your capture region is not quite aligned.

Q - Why is there a yellow border around OBS
A - Sadly this is due to the UWP Capture API. It's a "security feature" by Microsoft.

Q - I need help!
A - Join the Trauma Center Discord, and ask me there: https://discord.com/invite/h4qwmkY


SPECIAL THANKS:
Toufool & Avasam who created the AutoSplit software: https://github.com/Toufool/Auto-Split
Cosimo for helping me test!